# Obstacle_Avoidance_Path_Planning_Static_Environment
Obstacle Avoidance Path Planning in a Static Environment involves training an RL agent, such as a robot or autonomous vehicle, to navigate a fixed environment while avoiding collisions with static obstacles. 
